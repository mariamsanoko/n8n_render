# n8n-render

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)


## Environment Variables
* N8N_EDITOR_BASE_URL: The base URL of the n8n editor. Exemple: `https://xxxxxxx.onrender.com/`
* WEBHOOK_URL: The URL of the webhook. Exemple: `https://xxxxxxx.onrender.com/`